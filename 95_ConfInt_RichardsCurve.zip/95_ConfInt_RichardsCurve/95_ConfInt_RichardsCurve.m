%This routine creates a probability plot of the Richard's Curve when given
%the minimum and maximum values of its 95% confidence interval parameters.
%It assumes that the growth is contained within a calendar year and that
%the units of time are given in �decimal years�. The code can be amended if
%the time units are different (LINE 42) but be aware that the scaling of
%the x-axis in LINE 85 and the tick marks labels for the resulting figure
%(LINES 88 & 89) still assume that the calculations were done in decimal
%years so those will need to be changed as well.
%
%The first part of the routine introduces Richard's Curve, defines its
%parameters, prompts the user to input their values, and calculates a
%family of curves using the user input.
CreateStruct.Interpreter = 'latex';
CreateStruct.WindowStyle = 'non-modal';
CreateStruct.HorizontalAlignment= 'center';
string1 = 'Click OK to input the low and high values of the parameters of Richard`s Curve:';
string2 = '$\frac{1}{\left(1+T\mathrm{e}^{-k\left(x-x_{max}\right)}\right)^\frac{1}{T}}$';
string3 = 'Where T is the shape exponent,';
string4 = 'k is the growth rate,';
string5 = 'and $x_{max}$ is the time of maximum growth in decimal years.';
string6 = 'The time $x$ will be applied for you and starts from 1-Dec of "year-1" to 31-Jan of "year+1"';
h = mymsgbox({string1;string2;string3;string4;string5;string6},'Before we start',CreateStruct);%Create message box with custom settings developed by Ruengsakulrach (2016) 
set(h, 'position', [250 300 650 155] );%Make box bigger to fit text
ah = get( h, 'CurrentAxes' );
ch = get( ah, 'Children' );
set( ch, 'FontSize', 15);%Make text bigger
waitfor(h);
%
prompt={'MINIMUM value for the shape exponent',...
    'MAXIMUM value for the shape exponent',...
    'MINIMUM value for the growth rate',...
    'MAXIMUM value for the growth rate',...
    'MINIMUM value for the time of maximum growth (in decimal years)',...
    'MAXIMUM value for the time of maximum growth (in decimal years)',...
    'How many steps do you require when interpolating between the lowest and highest parameter values? The greater the number, the better the figure resolution but also the slower the process. (Recommended: 50-100)'}; 
dlgtitle='Richard`s Curve';
num_lines=1;
coefficients=inputdlg(prompt,dlgtitle,num_lines);%Prompt user for input
C=num2cell(str2double(coefficients));%Create matrix to store user input
[T_lo,T_hi,k_lo,k_hi,xmax_lo,xmax_hi,steps]=C{:};%Assing values to variables
%
x=linspace(-1/12,1+1/12,427);%Create daily time row vector from 1st-December of "year-1" to 31st-January of "year+1". Units of time are "decimal year".
T=linspace(T_lo,T_hi,steps);%Create interpolated row vector for shape exponent using user input
k=linspace(k_lo,k_hi,steps);%Create interpolated row vector for growth rate using user input
xmax=linspace(xmax_lo,xmax_hi,steps);%Create interpolated row vector for time of maxumum growth using user input
%
w = 0;%Dummy variable
 out = NaN(steps^3,length(x));%Create empty matrix in which to store results
      for a=1:steps
         for b =1:steps
             for c=1:steps
                
                 r = 1./((1+T(a)*exp(-k(b)*(x-xmax(c)))).^(1/T(a)));%Calculate family of Richard's Curves.
                 w = w+1;
                
             end
             out(w,:) = r;
         end
      end
%     
%The second part of the routine will generate a matrix with a frequency
% analysis of of the matrix generated in the first part. It counts how many
% times does the value of the regression falls between two values at a
% given time of the year.
ranges_edge1=linspace(0,0.999,1000)';%Generate first edge of ranges
ranges_edge2=linspace(0.001,1,1000)';%Generate second edge of ranges
[row_out, col_out] = size(out);
ranges = [ranges_edge1,ranges_edge2];%Generate matrix with edges
[row_ranges, cr] = size(ranges);
B = zeros(row_ranges, col_out);%Generate empty matrix in which to store results
for row = 1 : row_ranges
	B(row, :) = sum(out > ranges(row, 1) & out <= ranges(row, 2), 1);%Count results that fall between the edges and store in matrix B
end
B=flipud(B);%Flip matrix to have 0 at the bottom and 1 at the top
B=B./max(B).*95;%Convert count into percentages for every column
%
%The third part of the routine plots the results. It uses the "Custom
%Colormap" routine by Martinez-Cagigal (2020)
%V�ctor Mart�nez-Cagigal%(2020). Custom Colormap
%(https://www.mathworks.com/matlabcentral/fileexchange/69470-custom-colormap),
%MATLAB Central File Exchange. Retrieved June 19, 2020.
cblindmap=customcolormap(linspace(0,1,5),...
    {'#ff9900','#ffe67c','#aad7a8','#00b0f0','#ffffff'});%Create colourblind-firendly colourmap
%Plot the results
imagesc([1,15],[0,1],B);
ylabel('Growth fraction')
xlabel('Time (month)')
xticks(1:15)
xticklabels({' ','Jan',' ','Mar',' ','May',' ','Jul',' ','Sep',' ','Nov',' ','Jan'});
yticklabels({'1.0','0.9','0.8','0.7','0.6','0.5','0.4','0.3','0.2','0.1','0.0'});
colormap(cblindmap)
c=colorbar('Ticks',[0,15,35,55,75,95],...
    'TickLabels',{'\leq 5','    20','    40','    60','    80','\geq 95'});
c.Label.String='Probability (%)';